#ifndef _TEST_APP
#define _TEST_APP


#include "ofMain.h"
#include "ofxFileDialog.h"
#include "strokeGroup.h"
#include "grafIO.h"
#include "ofxVectorGraphics.h"

class testApp : public ofBaseApp{

	public:

		void setup();
		void update();
		void draw();

		void keyPressed  (int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void resized(int w, int h);
		
		vector <strokeGroup> currentTag;
		ofxFileDialog dialog;
		grafIO loader;
		
		vector <string> resultString;
		ofxVectorGraphics output;
		
		string currentFilename;
		bool saved;

};

#endif

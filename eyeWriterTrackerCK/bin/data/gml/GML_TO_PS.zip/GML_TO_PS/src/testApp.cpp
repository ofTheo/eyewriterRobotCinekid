#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(255, 255, 255);
	saved = true;
	ofSetDataPathRoot("../../../");
}

//--------------------------------------------------------------
void testApp::update(){
		
}

//--------------------------------------------------------------
void testApp::draw(){
	
	ofSetColor(0, 0, 0);
	ofDrawBitmapString("hit spacebar to load gml file", 10, 18);
	for(int i = 0; i < resultString.size(); i++){
		ofDrawBitmapString(resultString[i], 10, 38 + i * 18);
	}
	

	if( saved == false ){
		//char tmp[255];
		//getcwd(tmp, 255);
		//printf("cwd is %s\n", tmp);
		//printf("path is %s\n", string(currentFilename+"_converted.ps").c_str());
		output.beginEPS(currentFilename+"_converted.ps", 0, 0, 1024, 768);
	}

	output.noFill();
	output.setColor(0, 0, 0);
	
	for(int i = 0; i < currentTag.size(); i++){
		for(int k = 0; k < currentTag[i].strokes.size(); k++){
			if(  currentTag[i].strokes[k].hasPoints() ){
				output.beginShape();
					for(int d = 0; d < currentTag[i].strokes[k].pts.size(); d++){
						output.polyVertex(currentTag[i].strokes[k].pts[d].x, currentTag[i].strokes[k].pts[d].y);
					}
				output.endShape(false);
			}
		}
	}
	
	if( saved == false ){
		output.endEPS();
		saved = true;
		resultString.push_back("saved to: "+currentFilename+"_converted.ps");			
		resultString.push_back("success! - conversion complete.");			
	}
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){
	if(key == ' '){
	
		char msg[] = {"please select a gml file"};
		char msg2[] = {""};
		
		string result = dialog.getStringFromDialog(kDialogFile, msg, msg2);
			
		resultString.clear();
		resultString.push_back("attempting to load "+result);
		
		vector <string> checkDot = ofSplitString(result, ".");
		
		if( checkDot.size() && ( checkDot.back() != "gml" && checkDot.back() != "GML" ) ){
			resultString.push_back("error - incorrect file type");
		}else{

			vector <string> paths = ofSplitString(result, "/");
			if( paths.size() ){
				resultString.push_back("converting from gml");

				currentFilename = paths.back();
				loader.loadState(currentTag, result);
				saved = false;
			}
			
		}
	}
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::resized(int w, int h){

}

